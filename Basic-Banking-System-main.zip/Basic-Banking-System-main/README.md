# Basic-Banking-System
basic-banking-system | The Sparks Foundation Web development Internship Project : Basic banking system website .
The Sparks Foundation Web development Internship Project : Basic banking system website . A web application used to transfer virtual money between multiple users and also record the banking transactions .

Website has following features -> 
Start with a dummy data for upto 10 customers . Customer's table with basic fields such as name, email, current balance, etc. 
Transaction status: Transfer table/ Transfer History which records all the transactions .

Flow : 
          Home Page > View all customers > Select and View one customer > 
          Transfer Money > Select customer to transfer to > View all Customers
